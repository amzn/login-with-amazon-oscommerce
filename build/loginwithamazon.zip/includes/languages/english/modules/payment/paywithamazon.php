<?php
/**
 * Amazon Login - Login for osCommerce
 *
 * @category    Amazon
 * @package     Amazon_Login
 * @copyright   Copyright (c) 2015 Amazon.com
 * @license     http://opensource.org/licenses/Apache-2.0  Apache License, Version 2.0
 */
define('MODULE_PAYMENT_PAYWITHAMAZON_TEXT_TITLE', 'Pay With Amazon');
define('MODULE_PAYMENT_PAYWITHAMAZON_TEXT_DESCRIPTION', 'Pay With Amazon by Amazon Payments allows users to checkout using their saved addresses and credit cards from Amazon.');
define('MODULE_PAYMENT_PAYWITHAMAZON_STATUS', 'True');